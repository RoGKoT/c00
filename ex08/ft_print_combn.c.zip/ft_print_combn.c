/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rcote <rcote@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/26 16:46:14 by rcote             #+#    #+#             */
/*   Updated: 2022/09/30 14:17:09 by rcote            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_put_char(char c)
{
	write(1, &c, 1);
}
/*
void	ft_debug(char c[], int n, int crlf)
{
	int	i;

	i = 0;
	while (c[i] != '\0')
	{
		ft_put_char(c[i]);
		i++;
	}
	ft_put_char(n + '0');
	if (crlf > 0){ft_put_char('\n');}
}

void	ft_debug_comb(int comb[], int n)
{
	int	i;

	i = 0;
	ft_debug("comb", 91 - 48, 0);
	while (i <= n)
	{
		if (i > 0 )
		{
			ft_debug(",", comb[i], 0);
		}
		else
		{
			ft_debug("", comb[i], 0);
		}
		i++;
	}
	ft_debug("", 93 - 48, 1);
}
*/
void	ft_write_separator(void)
{
	ft_put_char(',');
	ft_put_char(' ');
}

void	ft_write_comb(int comb[],int n)
{
	int	i;

	i = 0;
	while (i <= n)
	{
		ft_put_char(comb[i] + '0');
		i++;
	}
}

void	ft_init_comb(int comb[], int n)
{
	while (n >= 0)
	{
		comb[n] = n;
		n--;
	}
}

void	ft_build_comb(int comb[], int n, int col)
{
	int	i;

	comb[col]++;
	i = col + 1;
	while (i <= n)
	{
		comb[i] = comb[i - 1] + 1;
		i++;
	}
}

void	ft_comb(int comb[], int n, int col)
{
	int	i;

	i = n - 1;
	if (comb[n] <= 9)
	{	
		ft_write_comb(comb, n);
		if (comb[0] < (9 - n + col)){ft_write_separator();}
		comb[n]++;
		ft_comb(comb, n, col);
	}
	while (i >= 0)
	{
		if (comb[i] <= (9 - n + col))
		{
			ft_build_comb(comb, n, i);
			ft_comb(comb, n, i);
		}
		else
		{		
			i--;
		}
	}
}

void	ft_print_combn(int n)
{
	int	comb[10];

	if ((n >= 0) && (n <= 9))
	{
		ft_init_comb(comb, 9);
		ft_comb(comb, n - 1, n - 1);
	}
}
